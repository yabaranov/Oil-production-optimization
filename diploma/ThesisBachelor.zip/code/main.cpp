#include "GNM.h"
#include "HDPoM.h"
#include <ctime>
int main(void)
{
	GridData gridData;
	gridData.ReadGrid();
	
	GNM gnm(gridData);
	gnm.ReadData();
	
	createDirectoriesHDPoM(gridData.GetNameModel(), 2 * gnm.GetNumberWells());
	InitializationHDPoM(gridData.GetSimulationTime());
	clock_t start = clock();
	gnm.IterativeProcess();
	clock_t end = clock();
	int seconds = int(end - start) / CLOCKS_PER_SEC;
	std::cout << "Time: " << seconds / 60 << " minutes " << seconds - (seconds / 60) * 60 << " seconds.\n ";

	WinExec("Python ResidualFunctional.py", 1);
	WinExec("Python PhaseByIter.py", 1);
	WinExec("Python Visualize.py", 1);
	WinExec("Python InitialPosWells.py", 1);

	//gnm.TestGeometry();
	
}
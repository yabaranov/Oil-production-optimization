#pragma once
#include "MatrixVector.h"
class SLAUGNM
{
private:

	Matrix m_M;
	Vector m_b;
	Vector m_x;

public:

	SLAUGNM() {}

	void GenerateSLAU(int n);
	static void Gauss(Matrix M, Vector b, Vector& x);
	int Size() { return m_M.size(); }
	const Matrix& GetM() { return m_M; }
	const Vector& Getb() { return m_b; }
	const Vector& Getx() { return m_x; }
	Matrix& SetM() { return m_M; }
	Vector& Setb() { return m_b; }
	Vector& Setx() { return m_x; }
};